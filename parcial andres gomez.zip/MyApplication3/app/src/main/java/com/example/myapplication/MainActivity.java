package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.lista.lista;

public class MainActivity extends AppCompatActivity {

    EditText usuarioEditText, contraseñaEditText;
    Button ingresarButton;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sharedPreferences = getSharedPreferences("MiPref", Context.MODE_PRIVATE);


        if (sharedPreferences.contains("usuario")) {

            Intent intent = new Intent(MainActivity.this, lista.class);
            startActivity(intent);
            finish();
        }


        usuarioEditText = findViewById(R.id.usuario);
        contraseñaEditText = findViewById(R.id.contraseña);
        ingresarButton = findViewById(R.id.ingresar);


        ingresarButton.setOnClickListener(v -> {
            String usuario = usuarioEditText.getText().toString();
            String contraseña = contraseñaEditText.getText().toString();


            if (usuario.equals("andres") && contraseña.equals("12345")) {

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("usuario", usuario);
                editor.apply();


                Intent intent = new Intent(MainActivity.this, lista.class);
                startActivity(intent);
                finish();
            } else {

                Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

