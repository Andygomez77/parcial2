package com.example.myapplication.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class adaptadores extends RecyclerView.Adapter<adaptadores.ViewHolder> {

    private List<Usuarios> datos;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Usuarios usuario);
    }

    public adaptadores(List<Usuarios> datos, OnItemClickListener listener) {
        this.datos = datos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public adaptadores.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemusuario, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull adaptadores.ViewHolder holder, int position) {
        Usuarios dato = datos.get(position);
        holder.bind(dato, listener);
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {


        ImageView img_usuario;
        TextView txt_nombre, txt_estado;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img_usuario = itemView.findViewById(R.id.img_usuario);
            txt_nombre = itemView.findViewById(R.id.txt_nombre);
            txt_estado = itemView.findViewById(R.id.txt_estado);
        }

        public void bind(Usuarios usuario, OnItemClickListener listener) {

            txt_nombre.setText(usuario.getNombre());
            txt_estado.setText(usuario.getEstado());
            Picasso.get().load(usuario.getImagen()).into(img_usuario);


            itemView.setOnClickListener(v -> listener.onItemClick(usuario));
        }
    }
}

