package com.example.myapplication.adaptadores;

public class Usuarios
{
    private String imagen;
 private  String nombre;
 private String estado;

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getImagen() {
        return imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEstado() {
        return estado;
    }
    public Usuarios(String imagen, String nombre, String estado){
        this.imagen=imagen;
        this.nombre=nombre;
        this.estado=estado;
    }
}
