package com.example.myapplication.lista;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.adaptadores.adaptadores;
import com.example.myapplication.adaptadores.Usuarios;
import com.example.myapplication.detalleusuario.detalldeusuario;


import java.util.ArrayList;
import java.util.List;

public class lista extends AppCompatActivity implements adaptadores.OnItemClickListener {

    RecyclerView rcv_usuarios;
    List<Usuarios> listaUsuarios = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);


        rcv_usuarios = findViewById(R.id.rcv_usuarios);


        rcv_usuarios.setLayoutManager(new LinearLayoutManager(this));


        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/1.jpg", "John Doe", "vivo"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/women/2.jpg", "Jane Smith", "vivo"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/3.jpg", "Michael Johnson", "muerto"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/women/4.jpg", "Emily Davis", "vivo"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/5.jpg", "David Brown", "muerto"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/women/6.jpg", "Sophia Wilson", "classical"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/7.jpg", "James Taylor", "reggae"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/women/8.jpg", "Olivia Thomas", "electronic"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/9.jpg", "Robert Lee", "metal"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/women/10.jpg", "Isabella Martin", "folk"));
        listaUsuarios.add(new Usuarios("https://randomuser.me/api/portraits/men/11.jpg", "William Garcia", "country"));


        rcv_usuarios.setAdapter(new adaptadores(listaUsuarios, this));
    }


    @Override
    public void onItemClick(Usuarios usuario) {

        Intent intent = new Intent(lista.this, detalldeusuario.class);
        intent.putExtra("nombre", usuario.getNombre());
        intent.putExtra("estado", usuario.getEstado());
        intent.putExtra("imagen", usuario.getImagen());
        startActivity(intent);
    }
}


