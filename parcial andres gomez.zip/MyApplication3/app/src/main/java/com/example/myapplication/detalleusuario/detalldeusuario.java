package com.example.myapplication.detalleusuario;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.squareup.picasso.Picasso;

public class detalldeusuario extends AppCompatActivity {
ImageView imgusuario;
TextView txtnombre, txtestado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalldeusuario);
        imgusuario = findViewById(R.id.imgDetalle);
        txtnombre = findViewById(R.id.txNombreDetalle);
        txtestado = findViewById(R.id.txtestado);
        String nombre = getIntent().getStringExtra("nombre");
        String estado = getIntent().getStringExtra("estado");
        String imagenurl = getIntent().getStringExtra("imagen");
        txtnombre.setText(nombre);
        txtestado.setText(estado);
        Picasso.get().load(imagenurl).into(imgusuario);
    }
}